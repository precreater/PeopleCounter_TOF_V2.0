#include "lvgl.h"
#include <TFT_eSPI.h>
#include <ArduinoLog.h>
#include "ui_event.h"
#include "Preferences.h"
#include "config.h"

void ui_init(void);
void update_count(int, int);