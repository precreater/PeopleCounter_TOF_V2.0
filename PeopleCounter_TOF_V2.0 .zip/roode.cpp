#include "roode.h"
#include <ArduinoLog.h>
#include "soc/rtc_wdt.h"
#include "ui.h"

#ifdef U8X8_HAVE_HW_SPI
#include <SPI.h>
#endif
#ifdef U8X8_HAVE_HW_I2C
#include <Wire.h>
#endif


namespace esphome {
namespace roode {

char buffer[400];
char EntryContent[20];
char ExitContent[20];
char ZoneContent[20];

void Roode::setup() {
  prefs.begin(NAMESPACE);
  this->config = new Config();
  this->config->initConfig();
  params_t params = this->config->getConfig();
  Log.infoln("%s===MAX_DISTANCE:%d, MIN_DISTANCE: %d, MAX_SAMPLING_SIZE: %d", TAG, params.MAX_DISTANCE, params.MIN_DISTANCE, params.MAX_SAMPLING_SIZE);
  this->set_sampling_size(params.MAX_SAMPLING_SIZE);
  this->distanceSensor = new TofSensor();
  this->distanceSensor->setup(0);
  this->calibrate_zones();
}

void Roode::loop() {
  long start = millis();
  this->current_zone->readDistance(distanceSensor);
  this->path_tracking(this->current_zone);
  this->handle_sensor_status();
  this->current_zone = this->current_zone == this->entry ? this->exit : this->entry;
}

void Roode::calibrate_zones() {
  Log.infoln("%s Calibrating sensor zones", SETUP);

  entry->reset_roi(orientation_ == Parallel ? 167 : 195);
  exit->reset_roi(orientation_ == Parallel ? 231 : 60);

  calibrateDistance();

  entry->roi_calibration(entry->threshold->idle, exit->threshold->idle, orientation_);
  entry->calibrateThreshold(distanceSensor, number_attempts);
  exit->roi_calibration(entry->threshold->idle, exit->threshold->idle, orientation_);
  exit->calibrateThreshold(distanceSensor, number_attempts);

  publish_sensor_configuration(entry, exit, true);
  // App.feed_wdt();
  rtc_wdt_feed();  //喂狗
  publish_sensor_configuration(entry, exit, false);
  ESP_LOGI(SETUP, "Finished calibrating sensor zones");
}

bool Roode::handle_sensor_status() {
  bool check_status = false;
  if (last_sensor_status != sensor_status && sensor_status == VL53L1_ERROR_NONE) {
    // if (status_sensor != nullptr) {
    //   status_sensor->publish_state(sensor_status);
    // }
    check_status = true;
  }
  if (sensor_status < 28 && sensor_status != VL53L1_ERROR_NONE) {
    ESP_LOGE(TAG, "Ranging failed with an error. status: %d", sensor_status);
    // status_sensor->publish_state(sensor_status);
    check_status = false;
  }

  last_sensor_status = sensor_status;
  sensor_status = VL53L1_ERROR_NONE;
  return check_status;
}

void Roode::calibrateDistance() {
  auto *const initial = distanceSensor->get_ranging_mode_override().value_or(Ranging::Longest);
  distanceSensor->set_ranging_mode(initial);

  entry->calibrateThreshold(distanceSensor, number_attempts);
  exit->calibrateThreshold(distanceSensor, number_attempts);

  if (distanceSensor->get_ranging_mode_override().has_value()) {
    return;
  }
  auto *mode = determine_raning_mode(entry->threshold->idle, exit->threshold->idle);
  if (mode != initial) {
    distanceSensor->set_ranging_mode(mode);
  }
}

void Roode::publish_sensor_configuration(Zone *entry, Zone *exit, bool isMax) {
}

const RangingMode *Roode::determine_raning_mode(uint16_t average_entry_zone_distance,
                                                uint16_t average_exit_zone_distance) {
  uint16_t min = average_entry_zone_distance < average_exit_zone_distance ? average_entry_zone_distance
                                                                          : average_exit_zone_distance;
  uint16_t max = average_entry_zone_distance > average_exit_zone_distance ? average_entry_zone_distance
                                                                          : average_exit_zone_distance;
  if (min <= short_distance_threshold) {
    return Ranging::Short;
  }
  if (max > short_distance_threshold && min <= medium_distance_threshold) {
    return Ranging::Medium;
  }
  if (max > medium_distance_threshold && min <= medium_long_distance_threshold) {
    return Ranging::Long;
  }
  if (max > medium_long_distance_threshold && min <= long_distance_threshold) {
    return Ranging::Longer;
  }
  return Ranging::Longest;
}

void Roode::path_tracking(Zone *zone) {
  // Serial.println("===path_tracking===");
  static int PathTrack[] = { 0, 0, 0, 0 };
  static int PathTrackFillingSize = 1;  // init this to 1 as we start from state
                                        // where nobody is any of the zones
  static int LeftPreviousStatus = NOBODY;
  static int RightPreviousStatus = NOBODY;
  static int flag_exit=0;
  static int flag_entry=0;
  static int flag_none=0;
  int CurrentZoneStatus = NOBODY;
  int AllZonesCurrentStatus = 0;
  int AnEventHasOccured = 0;

  // PathTrack algorithm
  params_t params = this->config->getConfig();
  // Log.infoln("%s===MAX_DISTANCE:%d, MIN_DISTANCE: %d, MAX_SAMPLING_SIZE: %d", TAG, params.MAX_DISTANCE, params.MIN_DISTANCE, params.MAX_SAMPLING_SIZE);
  if (zone->getMinDistance() < params.MAX_DISTANCE && zone->getMinDistance() > params.MIN_DISTANCE) {
    // if (zone->getMinDistance() < 1500 && zone->getMinDistance() > 10) {
    // Someone is in the sensing area
    CurrentZoneStatus = SOMEONE;
    // Log.noticeln("%s====CurrentZoneStatus SOMEONE====", TAG);
  }
  else{
    CurrentZoneStatus = NOBODY;
  }
  
  // left zone
  if (zone == (this->invert_direction_ ? this->exit : this->entry)) {
    if (CurrentZoneStatus != LeftPreviousStatus) {
      Log.noticeln("%s====LeftZone====", TAG);
      // Serial.println(buffer);
      // event in left zone has occured
      AnEventHasOccured = 1;

      if (CurrentZoneStatus == SOMEONE ) {
        AllZonesCurrentStatus += 1;
        flag_exit=1;
       Log.noticeln("left AllZonesCurrentStatus%d", AllZonesCurrentStatus);
      }
      // need to check right zone as well ...
      if (RightPreviousStatus == SOMEONE) {
        // event in right zone has occured
        AllZonesCurrentStatus += 2;
      }
      // remember for next time
      LeftPreviousStatus = CurrentZoneStatus;
    }
  }
  // right zone
  else {
    if (CurrentZoneStatus != RightPreviousStatus) {
      Log.notice("%s====RightZone===="   CR, TAG);
      // Serial.println(buffer);
      // event in right zone has occured
      AnEventHasOccured = 1;
      if (CurrentZoneStatus == SOMEONE) {
        AllZonesCurrentStatus += 2;
        flag_entry=1;
        Log.noticeln("right AllZonesCurrentStatus%d", AllZonesCurrentStatus);
      }
      // need to check left zone as well ...
      if (LeftPreviousStatus == SOMEONE) {
        // event in left zone has occured
        AllZonesCurrentStatus += 1;
      }
      // remember for next time
      RightPreviousStatus = CurrentZoneStatus;
    }
  }
  // if an event has occured
  if (AnEventHasOccured) {
    Log.traceln("%sEvent has occured, AllZonesCurrentStatus: %d", TAG, AllZonesCurrentStatus);
    if (PathTrackFillingSize < 4) {
      PathTrackFillingSize++;
    }

    // if nobody anywhere lets check if an exit or entry has happened
    if ((LeftPreviousStatus == NOBODY) && (RightPreviousStatus == NOBODY))
    {
        ESP_LOGD(TAG, "Nobody anywhere, AllZonesCurrentStatus: %d", AllZonesCurrentStatus);
        flag_none=1;
      }
    if(flag_none==1){
      // check exit or entry only if PathTrackFillingSize is 4 (for example 0 1
      // 3 2) and last event is 0 (nobobdy anywhere)
      if (PathTrackFillingSize == 4) {
        // check exit or entry. no need to check PathTrack[0] == 0 , it is
        // always the case
        
        if ((PathTrack[1] == 1) && (PathTrack[2] == 3) && (PathTrack[3] == 2)&&flag_exit==1) {
          // This an exit
          // Log.notice("Roode pathTracking Exit detected."CR);
          // ExitPeopleCnt += 1;
          prefs.putInt(EXIT_KEY, prefs.getInt(EXIT_KEY) + 1);
          this->updateCounter(-1);
          flag_exit=0;
        } else if ((PathTrack[1] == 2) && (PathTrack[2] == 3) && (PathTrack[3] == 1)&&flag_entry==1) {
          // This an entry
          // Log.notice("Roode pathTracking Entry detected."CR);
          // EntryPeopleCnt += 1;
          prefs.putInt(ENTRY_KEY, prefs.getInt(ENTRY_KEY) + 1);
          this->updateCounter(1);
          flag_entry=0;
        }
      }
      flag_none=0;
      PathTrackFillingSize = 1;
    } else {
      // update PathTrack
      // example of PathTrack update
      // 0
      // 0 1
      // 0 1 3
      // 0 1 3 1
      // 0 1 3 3
      // 0 1 3 2 ==> if next is 0 : check if exit
      Log.noticeln("path[%d]=%d",PathTrackFillingSize - 1, AllZonesCurrentStatus);
      PathTrack[PathTrackFillingSize - 1] = AllZonesCurrentStatus;
    }
  }
}

void Roode::updateCounter(int delta) {
  // ZonePeopleCnt += delta;
  if((prefs.getInt(ZONE_KEY) + delta)<0){
      prefs.putInt(ZONE_KEY, 0);
    }
    else{
      prefs.putInt(ZONE_KEY, prefs.getInt(ZONE_KEY) + delta);
    }
    Log.infoln("%s====ZonePeopleCnt:%d===", TAG, prefs.getInt(ZONE_KEY));
    this->writeScreen();
}
void Roode::recalibration() {
  calibrate_zones();
}

void Roode::writeScreen() {
  update_count(0, prefs.getInt(ENTRY_KEY));
  update_count(1, prefs.getInt(EXIT_KEY));
  update_count(2, prefs.getInt(ZONE_KEY));
}


}
}
