#include "ui.h"

void test(lv_event_t * e)
{
  Log.infoln("Click");
}