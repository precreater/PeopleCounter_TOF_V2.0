#include "ui.h"


static const uint16_t screenWidth = 320;   // 480;
static const uint16_t screenHeight = 240;  // 320;

static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf[screenWidth * screenHeight / 4];


TFT_eSPI tft = TFT_eSPI(screenWidth, screenHeight); /* TFT instance */
// TFT_Touch touch = TFT_Touch(DCS, DCLK, DIN, DOUT);

lv_obj_t* ui_home;
lv_obj_t* ui_setting;

lv_obj_t* entry_count_label;
lv_obj_t* exit_count_label;
lv_obj_t* zone_count_label;

static lv_style_t style_title;
static Preferences prefs;

void my_disp_flush(lv_disp_drv_t* disp, const lv_area_t* area, lv_color_t* color_p) {
  uint32_t w = (area->x2 - area->x1 + 1);
  uint32_t h = (area->y2 - area->y1 + 1);

  tft.startWrite();
  tft.setRotation(1);
  tft.setAddrWindow(area->x1, area->y1, w, h);
  tft.pushColors((uint16_t*)&color_p->full, w * h, true);
  tft.endWrite();
  lv_disp_flush_ready(disp);
}

void my_touchpad_read(lv_indev_drv_t* indev_driver, lv_indev_data_t* data) {
  uint16_t touchX, touchY;
  bool touched = tft.getTouch(&touchY, &touchX, 600);
  if (!touched) {
    data->state = LV_INDEV_STATE_REL;
  } else {
    data->state = LV_INDEV_STATE_PR;

    /*Set the coordinates*/
    data->point.x = 320 - touchX;
    data->point.y = touchY;
  }
}


void update_count(int type, int cnt) {
  switch (type) {
    case 0:  // entry
      {
        char label[4] = "";
        if (cnt == -9999) {
          int count = atoi(lv_label_get_text(entry_count_label));
          itoa(count + 1, label, 10);
        } else {
          itoa(cnt, label, 10);
        }
        lv_label_set_text(entry_count_label, label);
      }
      break;
    case 1:  // exit
      {
        char label[4] = "";
        if (cnt == -9999) {
          int count = atoi(lv_label_get_text(exit_count_label));
          itoa(count + 1, label, 10);
        } else {
          itoa(cnt, label, 10);
        }
        lv_label_set_text(exit_count_label, label);
      }
      break;
    case 2:  // zone
      {
        char label[4] = "";
        if (cnt == -9999) {
          int count = atoi(lv_label_get_text(zone_count_label));
          itoa(count + 1, label, 10);
        } else {
          itoa(cnt, label, 10);
        }
        lv_label_set_text(zone_count_label, label);
      }
      break;
  }
}

// 连续点击5次清零
int keyCnt = 0;
void setting_btn_clicked(lv_event_t* e) {
  // lv_disp_load_scr(ui_setting);
  keyCnt += 1;
  // 连续点击5次boot按钮，清空人员计数数据
  if (keyCnt % 5 == 0) {
    prefs.putInt(ENTRY_KEY, 0);
    prefs.putInt(EXIT_KEY, 0);
    prefs.putInt(ZONE_KEY, 0);
    update_count(0, prefs.getInt(ENTRY_KEY));
    update_count(1, prefs.getInt(EXIT_KEY));
    update_count(2, prefs.getInt(ZONE_KEY));
  }
}

void style_init() {
  lv_style_init(&style_title);
  lv_style_set_text_font(&style_title, &lv_font_montserrat_36);
}

void home_screen_init() {
  ui_home = lv_obj_create(NULL);
  lv_obj_set_width(ui_home, 320);
  lv_obj_set_height(ui_home, 240);
  lv_obj_clear_flag(ui_home, LV_OBJ_FLAG_SCROLLABLE);

  // 背景色
  lv_obj_set_style_bg_color(ui_home, lv_color_hex(0x003a57), LV_PART_MAIN);
}

void setting_screen_init() {
  ui_setting = lv_obj_create(NULL);
  lv_obj_set_width(ui_setting, 320);
  lv_obj_set_height(ui_setting, 240);
  lv_obj_clear_flag(ui_setting, LV_OBJ_FLAG_SCROLLABLE);
  // 背景色
  lv_obj_set_style_bg_color(ui_setting, lv_color_hex(0xeff0ee), LV_PART_MAIN);
}

void ui_init(void) {
  prefs.begin(NAMESPACE);
  tft.begin();
  // touch.setCal(526, 3443, 750, 3377, 320, 240, 1);
  // uint16_t calData[5] = { 211, 3532, 281, 3425, 5 };
  uint16_t calData[5] = { 380, 3499, 326, 3347, 6 };
  tft.setTouch(calData);

  lv_init();
  lv_disp_draw_buf_init(&draw_buf, buf, NULL, screenWidth * 10);

  /*Initialize the display*/
  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  /*Change the following line to your display resolution*/
  disp_drv.hor_res = screenWidth;
  disp_drv.ver_res = screenHeight;
  disp_drv.flush_cb = my_disp_flush;  // 刷新
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register(&disp_drv);

  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  style_init();
  home_screen_init();
  setting_screen_init();

  // LOGO图标
  LV_IMG_DECLARE(img_logo);
  lv_obj_t* logo_img = lv_img_create(ui_home);
  lv_img_set_src(logo_img, &img_logo);
  lv_obj_align(logo_img, LV_ALIGN_TOP_LEFT, 10, 10);


  lv_disp_load_scr(ui_home);
  // 设置按钮
  LV_IMG_DECLARE(img_setting);
  lv_obj_t* setting_img = lv_img_create(lv_scr_act());
  lv_obj_add_flag(setting_img, LV_OBJ_FLAG_CLICKABLE);
  //lv_obj_add_event_cb(setting_img, setting, LV_EVENT_CLICKED, &entry_count_label); /*Assign an event callback*/

  lv_img_set_src(setting_img, &img_setting);
  lv_obj_align(setting_img, LV_ALIGN_TOP_RIGHT, -10, 10);

  // 进区域
  lv_obj_t* entry = lv_obj_create(ui_home);
  lv_obj_set_width(entry, 93);
  lv_obj_set_height(entry, 150);
  lv_obj_align(entry, LV_ALIGN_TOP_LEFT, 10, 60);
  lv_obj_set_style_bg_color(entry, lv_color_hex(0xa9b8a8), LV_PART_MAIN);

  LV_IMG_DECLARE(img_entry);
  lv_obj_t* entry_img = lv_img_create(entry);
  lv_img_set_src(entry_img, &img_entry);
  lv_obj_align(entry_img, LV_ALIGN_TOP_MID, 0, 10);

  entry_count_label = lv_label_create(entry);
  char entry_text[4] = "";
  itoa(prefs.getInt(ENTRY_KEY), entry_text, 10);
  lv_label_set_text(entry_count_label, entry_text);
  lv_obj_add_style(entry_count_label, &style_title, 0);
  lv_obj_align(entry_count_label, LV_ALIGN_CENTER, 0, 30);

  // 出区域
  lv_obj_t* exit = lv_obj_create(ui_home);
  lv_obj_set_width(exit, 93);
  lv_obj_set_height(exit, 150);
  lv_obj_align(exit, LV_ALIGN_TOP_LEFT, 113, 60);
  lv_obj_set_style_bg_color(exit, lv_color_hex(0xa9b8a8), LV_PART_MAIN);

  LV_IMG_DECLARE(img_exit);
  lv_obj_t* exit_img = lv_img_create(exit);
  lv_img_set_src(exit_img, &img_exit);
  lv_obj_align(exit_img, LV_ALIGN_TOP_MID, 0, 10);

  exit_count_label = lv_label_create(exit);
  char exit_text[4] = "";
  itoa(prefs.getInt(EXIT_KEY), exit_text, 10);
  lv_label_set_text(exit_count_label, exit_text);
  lv_obj_add_style(exit_count_label, &style_title, 0);
  lv_obj_align(exit_count_label, LV_ALIGN_CENTER, 0, 30);

  // 总人数
  lv_obj_t* zone = lv_obj_create(ui_home);
  lv_obj_set_width(zone, 93);
  lv_obj_set_height(zone, 150);
  lv_obj_align(zone, LV_ALIGN_TOP_LEFT, 216, 60);
  lv_obj_set_style_bg_color(zone, lv_color_hex(0xa9b8a8), LV_PART_MAIN);

  LV_IMG_DECLARE(img_zone);
  lv_obj_t* zone_img = lv_img_create(zone);
  lv_img_set_src(zone_img, &img_zone);
  lv_obj_align(zone_img, LV_ALIGN_TOP_MID, 0, 10);

  zone_count_label = lv_label_create(zone);
  char zone_text[4] = "";
  itoa(prefs.getInt(ZONE_KEY), zone_text, 10);
  lv_label_set_text(zone_count_label, zone_text);
  lv_obj_add_style(zone_count_label, &style_title, 0);
  lv_obj_align(zone_count_label, LV_ALIGN_CENTER, 0, 30);

  // 绑定事件
  lv_obj_add_event_cb(setting_img, setting_btn_clicked, LV_EVENT_CLICKED, zone_count_label);

  /* lv_obj_add_style(label, &count_num_style, LV_PART_MAIN);*/
  //lv_obj_add_style(label, &font_style, LV_STATE_DEFAULT);
}
