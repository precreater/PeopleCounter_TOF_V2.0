 #ifndef _CONFIG.H
 #define _CONFIG.H

#include "Preferences.h"

#define NAMESPACE "CONFIG"
#define PARAMS_KEY "PARAMS"
#define ENTRY_KEY "ENTRY"
#define EXIT_KEY "EXIT"
#define ZONE_KEY "ZONE"


namespace esphome {
namespace roode {

  typedef struct {
      uint16_t MAX_DISTANCE;
      uint16_t MIN_DISTANCE;
      uint8_t MAX_SAMPLING_SIZE;
  } params_t;


  class Config {
    public:
      void initConfig();
      params_t getConfig();

    protected:
      Preferences prefs;
      params_t params;
      static const uint16_t max_distance = 1500;
      static const uint16_t min_distance = 10;
      static const uint8_t max_sampling_size = 2;
  };
  
}
}

#endif

