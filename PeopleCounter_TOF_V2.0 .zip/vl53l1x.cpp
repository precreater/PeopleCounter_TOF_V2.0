#include <stdint.h>
#include "vl53l1x.h"
#include <ArduinoLog.h>
#include "soc/rtc_wdt.h"

namespace esphome {
namespace vl53l1x {
char buffer[80];

void VL53L1X::setup(uint16_t sensorNo) {
  Serial.println("Beginning setup, SensorNo: " + String(sensorNo));

  // TODO use xshut_pin, if given, to change address
  auto status = this->init(sensorNo);
  Log.notice("%sSensorStatus:%d"CR  , TAG, status);
  if (status != VL53L1_ERROR_NONE) {
    // this->mark_failed();
    // TODO
    return;
  }
  ESP_LOGD(TAG, "Device initialized");

  if (this->offset.has_value()) {
    ESP_LOGI(TAG, "Setting offset calibration to %d", this->offset.value());
    status = this->sensor.SetOffsetInMm(this->offset.value());
    if (status != VL53L1_ERROR_NONE) {
      ESP_LOGE(TAG, "Could not set offset calibration, error code: %d", status);
      // this->mark_failed();
      return;
    }
  }

  if (this->xtalk.has_value()) {
    ESP_LOGI(TAG, "Setting crosstalk calibration to %d", this->xtalk.value());
    status = this->sensor.SetXTalk(this->xtalk.value());
    if (status != VL53L1_ERROR_NONE) {
      ESP_LOGE(TAG, "Could not set crosstalk calibration, error code: %d", status);
      // this->mark_failed();
      return;
    }
  }

  ESP_LOGI(TAG, "Setup complete");
}

VL53L1_Error VL53L1X::init(uint16_t sensorNo) {
  Log.notice("%s: Trying to initialize"CR   , TAG);

  VL53L1_Error status;

  // If address is non-default, set and try again.
  if (address_ != (sensor.GetI2CAddress() >> 1)) {
    ESP_LOGD(TAG, "Setting different address");
    status = sensor.SetI2CAddress(address_ << 1);
    if (status != VL53L1_ERROR_NONE) {
      // ESP_LOGE(TAG, "Failed to change address. Error: %d", status);
      Log.notice("%s===Failed to change address. Error===%d"CR   , TAG, status);
      return status;
    }
  }

  // status = wait_for_boot();
  // if (status != VL53L1_ERROR_NONE) {
  //   Log.error("%swait_for_boot===status:"CR, TAG, status);
  //   return status;
  // }

  Log.notice("%sFound device, initializing..."CR  , TAG);
  // status = sensor.Init();
  if (sensorNo == 0) {
    status = sensor.Begin(0x55);
    sensor.SetI2CAddress(0x55);
    uint8_t address2;
    address2 = sensor.GetI2CAddress();

  } else if (sensorNo == 1) {
    status = sensor.Begin();
    uint8_t address1;
    address1 = sensor.GetI2CAddress();

  }
  
  if (status != VL53L1_ERROR_NONE) {
    Log.error("%sCould not initialize device, error code: %d"CR   , TAG, status);
    return status;
  }

  return status;
}

VL53L1_Error VL53L1X::wait_for_boot() {
  // Wait for firmware to copy NVM device_state into registers
  delayMicroseconds(1200);

  uint8_t device_state;
  VL53L1_Error status;
  auto start = millis();
  while ((millis() - start) < 2000) {
    status = get_device_state(&device_state);
    if (status != VL53L1_ERROR_NONE) {
      return status;
    }
    if ((device_state & 0x01) == 0x01) {
      Log.notice("%sFinished waiting for boot. Device state: %d"CR   , TAG, device_state);
      return VL53L1_ERROR_NONE;
    }
    // App.feed_wdt();
    rtc_wdt_feed();  //喂狗
  }

  Log.warning("%sTimed out waiting for boot. state: %d"CR    , TAG, device_state);
  return VL53L1_ERROR_TIME_OUT;
}

VL53L1_Error VL53L1X::get_device_state(uint8_t *device_state) {
  VL53L1_Error status = sensor.GetBootState(device_state);
  if (status != VL53L1_ERROR_NONE) {
    ESP_LOGE(TAG, "Failed to read device state. error: %d", status);
    return status;
  }

  // Our own logic...device_state is 255 when unable to complete read
  // Not sure why and why other libraries don't account for this.
  // Maybe somehow this is supposed to be 0, and it is getting messed up in I2C layer.
  if (*device_state == 255) {
    *device_state = 98;  // Unknown
  }

  ESP_LOGI(TAG, "Device state: %d", *device_state);

  return VL53L1_ERROR_NONE;
}

void VL53L1X::set_ranging_mode(const RangingMode *mode) {
  // if (this->is_failed()) {
  //   ESP_LOGE(TAG, "Cannot set ranging mode while component is failed");
  //   return;
  // }

  auto status = this->sensor.SetDistanceMode(mode->mode);
  if (status != VL53L1_ERROR_NONE) {
    ESP_LOGE(TAG, "Could not set distance mode: %d, error code: %d", mode->mode, status);
  }

  status = this->sensor.SetTimingBudgetInMs(mode->timing_budget);
  if (status != VL53L1_ERROR_NONE) {
    ESP_LOGE(TAG, "Could not set timing budget: %d ms, error code: %d", mode->timing_budget, status);
  }

  status = this->sensor.SetInterMeasurementInMs(mode->delay_between_measurements);
  if (status != VL53L1_ERROR_NONE) {
    ESP_LOGE(TAG, "Could not set measurement delay: %d ms, error code: %d", mode->delay_between_measurements, status);
  }

  this->ranging_mode = mode;
  ESP_LOGI(TAG, "Set ranging mode: %s", mode->name);
}

optional<uint16_t> VL53L1X::read_distance(ROI *roi, VL53L1_Error &status) {
  // if (this->is_failed()) {
  //   ESP_LOGW(TAG, "Cannot read distance while component is failed");
  //   return {};
  // }

  sprintf(buffer, "%sBeginning distance read", TAG);
  // Serial.println(buffer);

  if (last_roi == nullptr || *roi != *last_roi) {
    sprintf(buffer, "%sSetting new ROI: { width: %d, height: %d, center: %d }", TAG, roi->width, roi->height, roi->center);
    // Serial.println(buffer);
    status = this->sensor.SetROI(roi->width, roi->height);
    // status = this->sensor.SetROI(6, 16);
    // Serial.println(status);
    if (status != VL53L1_ERROR_NONE) {
      ESP_LOGE(TAG, "Could not set ROI width/height, error code: %d", status);
      return {};
    }
    status = this->sensor.SetROICenter(roi->center);
    // status = this->sensor.SetROICenter(167);
    if (status != VL53L1_ERROR_NONE) {
      ESP_LOGE(TAG, "Could not set ROI center, error code: %d", status);
      return {};
    }
    last_roi = roi;
  }
  status = this->sensor.StartRanging();

  // Wait for the measurement to be ready
  // TODO use interrupt_pin, if given, to await data ready instead of polling
  uint8_t dataReady = false;
  while (!dataReady) {
    status = this->sensor.CheckForDataReady(&dataReady);
    if (status != VL53L1_ERROR_NONE) {
      Serial.println("Failed to check if data is ready, error code: " + String(status));
      return {};
    }
    delay(1);
    // App.feed_wdt();
  }
  // Get the results
  uint16_t distance;
  status = this->sensor.GetDistanceInMm(&distance);
  if (status != VL53L1_ERROR_NONE) {
    sprintf(buffer, "%sCould not get distance, error code: %d", TAG, status);
    Serial.println(buffer);
    return {};
  }
  // After reading the results reset the interrupt to be able to take another measurement
  status = this->sensor.ClearInterrupt();
  if (status != VL53L1_ERROR_NONE) {
    sprintf(buffer, "%sCould not clear interrupt, error code: %d", TAG, status);
    Serial.println(buffer);
    return {};
  }
  status = this->sensor.StopRanging();
  if (status != VL53L1_ERROR_NONE) {
    sprintf(buffer, "%s, Could not stop ranging, error code: %d", TAG, status);
    Serial.println(buffer);
    return {};
  }

  sprintf(buffer, "%s, Finished distance read: %d", TAG, distance);
  // Serial.println(buffer);
  return {distance};
}

}  // namespace vl53l1x
}  // namespace esphome
