#include "config.h"
#include "ArduinoLog.h"

namespace esphome {
  namespace roode {
    char *TAG = "CONFIG: ";

    void Config::initConfig() {
      Log.noticeln("%s=====init config=======", TAG);
      prefs.begin(NAMESPACE);
      size_t configLen = prefs.getBytesLength(PARAMS_KEY);
      if (configLen == 0) {
        Log.traceln("%s======set default config", TAG);
        params_t params = {max_distance, min_distance, max_sampling_size};
        prefs.putBytes(PARAMS_KEY, &params, sizeof(params));
        Log.traceln("%s========write config success=======", TAG);
      }

      configLen = prefs.getBytesLength(PARAMS_KEY);
      if (configLen == 0) {
        Log.errorln("%s=========ERROR: config length is zero===========", TAG);
      } else {
        char buffer[configLen];
        prefs.getBytes(PARAMS_KEY, buffer, configLen);
        params = (*(params_t *) buffer);
        // Log.infoln("%s===MAX_DISTANCE:%d, MIN_DISTANCE: %d, MAX_SAMPLING_SIZE: %d", TAG, config->MAX_DISTANCE, config->MIN_DISTANCE, config->MAX_SAMPLING_SIZE);
      }

      // 人员计数初始化
      int entryCnt = prefs.getInt(ENTRY_KEY, -1);
      if (entryCnt == -1) {
        prefs.putInt(ENTRY_KEY, 0);
      }
      int exitCnt = prefs.getInt(EXIT_KEY, -1);
      if (exitCnt == -1) {
        prefs.putInt(EXIT_KEY, 0);
      }
      int zoneCnt = prefs.getInt(ZONE_KEY, -1);
      if (zoneCnt == -1) {
        prefs.putInt(ZONE_KEY, 0);
      }
      
    }

    params_t Config::getConfig() {
      return params;
    }

  }
}