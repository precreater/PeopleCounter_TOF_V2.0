#pragma once
#include <math.h>

#include "esp_log.h"
#include "optional.h"
#include "vl53l1x.h"
#include "orientation.h"
#include <ArduinoLog.h>

using TofSensor = esphome::vl53l1x::VL53L1X;
using esphome::vl53l1x::ROI;


static const char *const CALIBRATION = "Zone calibration";
namespace esphome {
namespace roode {

static const char* TAG = "Roode: ";

struct Threshold {
  /** Automatically determined idling distance (average of several measurements) */
  uint16_t idle;
  uint16_t min;
  optional<uint8_t> min_percentage{};
  uint16_t max;
  optional<uint8_t> max_percentage{};
  void set_min(uint16_t min) { this->min = min; }
  void set_min_percentage(uint8_t min) { this->min_percentage = min; }
  void set_max(uint16_t max) { this->max = max; }
  void set_max_percentage(uint8_t max) { this->max_percentage = max; }
};

class Zone {
 public:
  void init();
  explicit Zone(uint8_t id) : id{id} {};
  void dump_config() const;
  VL53L1_Error readDistance(TofSensor *distanceSensor);
  void reset_roi(uint8_t default_center);
  void calibrateThreshold(TofSensor *distanceSensor, int number_attempts);
  void roi_calibration(uint16_t entry_threshold, uint16_t exit_threshold, Orientation orientation);
  const uint8_t id;
  uint16_t getDistance() const;
  uint16_t getMinDistance() const;
  ROI *roi = new ROI();
  ROI *roi_override = new ROI();
  Threshold *threshold = new Threshold();
  void set_max_samples(uint8_t max) { max_samples = max; };

 protected:
  int getOptimizedValues(int *values, int sum, int size);
  VL53L1_Error last_sensor_status = VL53L1_ERROR_NONE;
  VL53L1_Error sensor_status = VL53L1_ERROR_NONE;
  uint16_t last_distance;
  uint16_t min_distance;
  std::vector<uint16_t> samples;
  uint8_t max_samples;
};
}  // namespace roode
}  // namespace esphome
